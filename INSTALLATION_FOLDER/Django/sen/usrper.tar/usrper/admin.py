from django.contrib import admin
from usrper.models import *

admin.site.register(students)
